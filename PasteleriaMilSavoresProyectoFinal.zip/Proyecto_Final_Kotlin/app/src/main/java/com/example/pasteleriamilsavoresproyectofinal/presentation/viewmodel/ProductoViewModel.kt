package com.example.pasteleriamilsavoresproyectofinal.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.pasteleriamilsavoresproyectofinal.data.model.Producto
import com.example.pasteleriamilsavoresproyectofinal.data.repository.ProductoRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class ProductoViewModel : ViewModel() {

    // Repository (fuente de datos)
    private val repository = ProductoRepository()

    // Estado PRIVADO (solo el ViewModel puede modificarlo)
    private val _uiState = MutableStateFlow(ProductoUIState())

    // Estado PÚBLICO (solo lectura desde la UI)
    val uiState: StateFlow<ProductoUIState> = _uiState.asStateFlow()

    init {
        cargarProductos()
    }

    /**
     * Carga todos los productos desde el repositorio
     */
    fun cargarProductos() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)
            try {
                val productos = repository.obtenerProductos()
                _uiState.value = _uiState.value.copy(
                    productos = productos,
                    isLoading = false
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    errorMessage = "Error al cargar productos: ${e.message}"
                )
            }
        }
    }

    /**
     * Busca productos por texto
     */
    fun buscarProductos(query: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)
            try {
                val productos = if (query.isBlank()) {
                    repository.obtenerProductos()
                } else {
                    repository.buscarProductos(query)
                }

                _uiState.value = _uiState.value.copy(
                    productos = productos,
                    isLoading = false
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    errorMessage = "Error en la búsqueda: ${e.message}"
                )
            }
        }
    }

    /**
     * Ordena los productos por precio (de menor a mayor)
     */
    fun ordenarPorPrecio() {
        viewModelScope.launch {
            val productosOrdenados = _uiState.value.productos.sortedBy { it.precio }
            _uiState.value = _uiState.value.copy(productos = productosOrdenados)
        }
    }

    /**
     * Filtra los productos disponibles (por ejemplo, stock > 0)
     */
    fun filtrarPorDisponibilidad() {
        viewModelScope.launch {
            val disponibles = _uiState.value.productos.filter { it.disponible }
            _uiState.value = _uiState.value.copy(productos = disponibles)
        }
    }

    /**
     * Estado de la UI
     */
    data class ProductoUIState(
        val productos: List<Producto> = emptyList(),
        val isLoading: Boolean = false,
        val errorMessage: String? = null
    )
}

