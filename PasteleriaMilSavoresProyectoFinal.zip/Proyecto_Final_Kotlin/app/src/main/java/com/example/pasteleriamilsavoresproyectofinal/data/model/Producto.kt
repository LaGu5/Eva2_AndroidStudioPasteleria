package com.example.pasteleriamilsavoresproyectofinal.data.model

/**
 * Modelo de datos: Producto
 * Representa un producto en nuestra aplicación
 */
data class Producto(
    val id: Int,
    val nombre: String,
    val descripcion: String,
    val precio: Double,
    val stock: Int,
    val categoria: String
) {
    // Propiedad calculada: el producto está disponible si tiene stock
    val disponible: Boolean
        get() = stock > 0

    // Formato del precio con símbolo de dólar
    val precioFormateado: String
        get() = "$%.2f".format(precio)
}