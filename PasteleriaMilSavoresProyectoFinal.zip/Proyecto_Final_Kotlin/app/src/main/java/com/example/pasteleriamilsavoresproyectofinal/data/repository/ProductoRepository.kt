package com.example.pasteleriamilsavoresproyectofinal.data.repository

import com.example.pasteleriamilsavoresproyectofinal.data.model.Producto
import kotlinx.coroutines.delay

class ProductoRepository {

    // Simulación de base de datos en memoria
    private val productos = mutableListOf(

        Producto(1,"Torta Cuadrada de Chocolate", "Torta de chocolate con ganache y avellanas", 4500.0, 8,"Tortas"),
        Producto(2,"Torta Circular de Vainilla", "Bizcocho de vainilla con crema pastelera", 4000.0, 6,"Tortas"),
        Producto(3,"Cheesecake Sin Azúcar", "Suave y cremoso, endulzado naturalmente", 4700.0, 5,"Aperitivos"),
        Producto(4,"Torta Vegana de Chocolate", "Hecha sin productos de origen animal", 5000.0, 4,"Tortas"),
        Producto(5,"Empanada de Manzana", "Pastelería tradicional rellena de manzana", 3000.0, 10,"Aperitivos"),
        Producto(6,"Tarta de Santiago", "Tarta española con almendras y azúcar ", 6000.0, 7,"Tortas"),
        Producto(7,"Celestino","Panqueque con manjar con helado a eleccion",7000.0,5,"Aperitivos"),
        Producto(8,"Galletas de Chocolate","Crujientes galletas bañadas en chocolate",2500.0,15,"Aperitivos"),
        Producto(9,"Empolbado con manjar","Empolbado suave con un poco de coco en los bordes",5000.0,2,"Aperitivos"),
        Producto(10,"Torta de Maracuya","Torta hecha con productos naturales y lista para comer",5500.0,7,"Tortas"),
        Producto(11,"Cheesecake de frambuesa","cremoso y rico con una gran cantidad de frambuesa",7500.0,8,"Aperitivos"),
        Producto(12,"Kuchen de manzana","Kuchen con gran cantidad de manzana picada ",8000.0,20,"Aperitivos")

    )

    /**
     * Obtiene todos los productos
     * suspend: función suspendible (asíncrona)

     * ** Explicación:**
     *  Repository Pattern: Abstrae la fuente de datos
     *  suspend : Funciones asíncronas para operaciones de red/BD
     *  delay() : Simula latencia de red
     *  En una app real: Retro t (API), Room (BD local)

     */
    suspend fun obtenerProductos(): List<Producto> {
        // Simula latencia de red (1 segundo)
        delay(1000)
        return productos.toList()
    }

    /**
     * Busca productos por nombre o descripción
     */
    suspend fun buscarProductos(query: String): List<Producto> {
        delay(500)
        return productos.filter {
            it.nombre.contains(query, ignoreCase = true) ||
                    it.descripcion.contains(query, ignoreCase = true)
        }
    }

    /**
     * Filtra productos por categoría
     */
    suspend fun obtenerPorCategoria(categoria: String): List<Producto> {
        delay(300)
        return productos.filter { it.categoria == categoria }
    }
}
