package com.example.pasteleriamilsavoresproyectofinal.data.repository

import retrofit2.http.GET
import com.example.pasteleriamilsavoresproyectofinal.data.model.Producto

interface ProductoApi {
    @GET("products") // Endpoint real de la FakeStoreAPI
    suspend fun obtenerProductos(): List<Producto>
}
